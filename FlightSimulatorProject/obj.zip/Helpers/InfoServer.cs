﻿using FlightSimulatorProject.Interfaces;
using FlightSimulatorProject.Views;
using OxyPlot;
using OxyPlot.Axes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MathNet.Numerics.Statistics;
using MathNet.Numerics;

namespace FlightSimulatorProject.Helpers
{
    class InfoServer : IServer
    {
        FileParser csvParser;
        private TcpListener listener;
        private TcpClient client;
        private BinaryReader reader;
        Thread getInfoThread;

        Dictionary<string, string> correlationDict = new Dictionary<string, string>();
        Dictionary<string, Func<double, double>> linearRegressionCurves = new Dictionary<string, Func<double, double>>();
        Dictionary<string, Tuple<double, double>> graphBondaries = new Dictionary<string, Tuple<double, double>>();

        Dictionary<string, List<DataPoint>> linearRegressionCurves2 = new Dictionary<string, List<DataPoint>>();

        const string LOCAL_HOST = "127.0.0.1";
        const int PORT = 6400;
        double time = 0;
        public bool Connected { get; set; } = false;
        public bool Stop { get; set; } = false;
        public DataPoint LastFeaturePoint { get; set; }
        public DataPoint LastCorrelatedFeaturePoint { get; set; }
        public DataPoint LastLinearRegressionPoint { get; set; }

        public int DataSize
        {
            get
            {
                return csvParser.DataDict["aileron"].Count();
            }
        }
        public Func<double,double> getCurve(string feature)
        {

            return linearRegressionCurves[feature];
        }

        public double getMinGraphBoundery(string feature)
        {
            return graphBondaries[feature].Item1;
        }
        public double getMaxGraphBoundery(string feature)
        {
            return graphBondaries[feature].Item2;
        }
        private void initalGraphBounderis()
        {
            foreach (var feature in csvParser.DataDict)
            {
                /*ConsoleAllocator.ShowConsoleWindow();
                Console.WriteLine("min" + feature.Value.Min());
                Console.WriteLine("max" + feature.Value.Max());*/
                Tuple<double, double> data = new Tuple<double, double>(feature.Value.Min(), feature.Value.Max());
                graphBondaries.Add(feature.Key, data);

            }
        }

        string _feature = "aileron"; //defult value
        public string Feature
        {
            get
            {
                return _feature;
            }
            set
            {
                if (_feature != value)
                {
                    _feature = value;
                    OnPropertyChange("Feature");
                    OnPropertyChange("CorrelatedFeature");


                }
            }
        }

        string _correlatedFeature = "longitude-deg";

        public string CorrelatedFeature
        {
            get
            {
                return _correlatedFeature;
            }
            set
            {
                if (_correlatedFeature != value)
                {
                    _correlatedFeature = value;
                    OnPropertyChange("CorrelatedFeature");

                }
            }
        }


        private void validateValues(ref double a)
        {
            if (Double.IsNaN(a))
            {
                a = 0;
            }
            else if (Double.IsInfinity(a))
            {
                a = 1;
            } else
            {
                return;
            }
        }
        public void initialCurves()
        {
            foreach (var pair in correlationDict)
            {
                var xdata = csvParser.DataDict[pair.Key].ToArray();
                var ydata = csvParser.DataDict[pair.Value].ToArray();
                //var xdata = new double[] { 10, 20, 30, 40, 50 };
                //var ydata = new double[] { 15, 20, 25, 55, 95 };
                double[] p = Fit.Polynomial(xdata, ydata, 1);
                var a = p[1]; 
                var b = p[0];
                validateValues(ref a);
                validateValues(ref b);
                ConsoleAllocator.ShowConsoleWindow();
                Console.WriteLine(a);
                Console.WriteLine(b);
                Console.WriteLine("\n\n");

                Func<double, double> linearCurve = (x) => a * x + b;
                linearRegressionCurves.Add(pair.Key, linearCurve);

            }
        }

        public List<DataPoint> getCurvePoints(string feature)
        {
            return linearRegressionCurves2[feature];
        }

        /*
        public void initialCurves()
        {
            foreach (var pair in correlationDict)
            {
                var xdata = csvParser.DataDict[pair.Key].ToArray();
                var ydata = csvParser.DataDict[pair.Value].ToArray();
                double[] p = Fit.Polynomial(xdata, ydata, 1);
                var a = p[1];
                var b = p[0];
                validateValues(ref a);
                validateValues(ref b);
                //double intersectionX = -b / a;
                double intersectionY = b;
                double minFeatureValue = csvParser.DataDict[pair.Key].Min();
                double minCorrelatedFeatureValue = csvParser.DataDict[pair.Value].Min();
                double maxFeatureValue = csvParser.DataDict[pair.Key].Max();
                double maxCorrelatedFeatureValue = csvParser.DataDict[pair.Value].Max();

                //DataPoint intersectionPointX = new DataPoint(intersectionX, 0);
                //DataPoint intersectionPointY = new DataPoint(0, intersectionY);
                DataPoint minPoint = new DataPoint(minFeatureValue, minCorrelatedFeatureValue);
                ConsoleAllocator.ShowConsoleWindow();
                Console.WriteLine(pair.Key);
                Console.WriteLine("\n\n");
                Console.WriteLine(pair.Key + minFeatureValue);
                Console.WriteLine(pair.Key + maxFeatureValue);

                ConsoleAllocator.ShowConsoleWindow();
                Console.WriteLine(pair.Value + minCorrelatedFeatureValue);
                Console.WriteLine(pair.Value + maxCorrelatedFeatureValue);
                DataPoint maxPoint = new DataPoint(maxCorrelatedFeatureValue, maxFeatureValue);

                List<DataPoint> linearCurvePoints = new List<DataPoint>{//intersectionPointX,
                                                        //intersectionPointY,
                                                        minPoint,
                                                        maxPoint};
                                                        
                foreach (var dp in linearCurvePoints)
                {
                    Console.WriteLine("point x" + dp.X);
                    Console.WriteLine("point y" + dp.Y);

                }


                linearRegressionCurves2.Add(pair.Key, linearCurvePoints);
            }
        }*/

        public void initialCorrelatedFeatures()
        {
            double currentCorrelation;
            double bestCorrelation = -1;
            string mostCorrelativeFeature = "";

            for (int i = 0; i < this.csvParser.DataDict.Count(); i++)
            {
                for (int j = 0; j < this.csvParser.DataDict.Count(); j++)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    currentCorrelation = Correlation.Pearson(this.csvParser.DataDict.ElementAt(i).Value,
                                                this.csvParser.DataDict.ElementAt(j).Value);

                    if (Double.IsNaN(currentCorrelation))
                    {
                        currentCorrelation = 0;
                    }

                    if (currentCorrelation > bestCorrelation)
                    {
                        bestCorrelation = currentCorrelation;
                        mostCorrelativeFeature = convertNumToFeature(j);
                    }
                }
                correlationDict.Add(convertNumToFeature(i), mostCorrelativeFeature);
                bestCorrelation = -1;
                mostCorrelativeFeature = "";

            }
        }

        private void printCorrelativeFeatures()
        {
            ConsoleAllocator.ShowConsoleWindow();

            foreach (var v in correlationDict)
            {
                /*
                Console.Write(v.Key);
                Console.Write(" ");
                Console.Write(v.Value.Item1);
                Console.Write(" ");
                Console.Write(v.Value.Item2);
                Console.Write(" ");
                Console.Write("\n");
                */
                Console.Write(v.Key);
                Console.Write(" ");
                Console.Write(v.Value);
                Console.Write("\n");




            }
        }
        public InfoServer()
        {
            this.csvParser = new FileParser();
            this.csvParser.initializeData();
            initialCorrelatedFeatures();
            initialCurves();
            initalGraphBounderis();
        }
        // open server with ip and port
        public void Open()
        {
            if (listener != null) Close();
            listener = new TcpListener(new IPEndPoint(IPAddress.Parse(LOCAL_HOST), PORT));
            listener.Start();
        }

        public void Close() { client.Close(); listener.Stop(); Connected = false; }

        // read simulator input and return it to the model
        public string[] Read()
        {
            if (!Connected)
            {
                Connected = true;
                client = listener.AcceptTcpClient();
                ConsoleAllocator.ShowConsoleWindow();
                Console.WriteLine("Connected!");
                reader = new BinaryReader(client.GetStream());
            }

            string input = ""; // input will be stored here
            char s;

            while ((s = reader.ReadChar()) != '\n') input += s; // read untill \n
            string[] param = input.Split(','); // split by comma
            string[] ret = { param[0], param[1], param[2], param[3], param[4],
                            param[5], param[6], param[7], param[8], param[9],
                            param[10], param[11], param[12], param[13], param[14],
                            param[15], param[16], param[17], param[18], param[19],
                            param[20], param[21], param[22], param[23], param[24],
                            param[25], param[26], param[27], param[28], param[29],
                            param[30], param[31], param[32], param[33], param[34],
                            param[35], param[36], param[37], param[38], param[39], param[40], param[41]};
            return ret;
        }

        private string convertNumToFeature(int index)
        {
            List<string> features = csvParser.DataDict.Keys.ToList();
            return features.ElementAt(index);
        }
        private int convertFeatureToNumber(string featureName)
        {
            /*ConsoleAllocator.ShowConsoleWindow();
            Console.WriteLine(featureName);
            */
            List<string> features = csvParser.DataDict.Keys.ToList();
            //Console.WriteLine(features.IndexOf(featureName));
            return features.IndexOf(featureName);
            
        }
        void StartRead()
        {

            while (!Stop)
            {
                string[] args = Read();
                //ConsoleAllocator.ShowConsoleWindow();

                LastFeaturePoint = new DataPoint(time += 0.1, Convert.ToDouble(args[convertFeatureToNumber(Feature)]));
                LastCorrelatedFeaturePoint = new DataPoint(time, Convert.ToDouble(args[convertFeatureToNumber(CorrelatedFeature)]));
                LastLinearRegressionPoint = new DataPoint(Convert.ToDouble(args[convertFeatureToNumber(Feature)]),
                                                            Convert.ToDouble(args[convertFeatureToNumber(CorrelatedFeature)]));
                Thread.Sleep(100);

            }
        }
        public void ReadThread()
        {
            getInfoThread = new Thread(() => StartRead());
            if (!(getInfoThread.ThreadState == ThreadState.Running))
            {
                getInfoThread.Start();
            };
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                if (propertyName == "CorrelatedFeature")
                {
                    CorrelatedFeature = correlationDict[Feature];
                }
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}

