﻿using FlightSimulatorProject.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FlightSimulatorProject.Views
{
    /// <summary>
    /// Interaction logic for PanelView.xaml
    /// </summary>
    public partial class PanelView : UserControl
    {
        MasterViewModel m;
        GraphWindow graphWindow;
        public PanelView()
        {
            InitializeComponent();
            m = new MasterViewModel();
            this.DataContext = m;


        }

        //public MasterViewModel M { get; set; }
        public void SetFeature(string s)
        {
            m.Feature = s;
        }
        private void Play_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.Play();
        }

        private void FastForward_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.FastForward();

        }

        private void Connect_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.Connect();
        }

        private void Pause_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.Pause();

        }

        private void fastBackward_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.FastBackward();
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.Stop();
        }

        private void VideoSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            m.VM_Panel.Panel.DataIndex = (int)slValue.Value;

        }

        private void faster_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.Faster();
        }

        private void slower_Click(object sender, RoutedEventArgs e)
        {
            m.VM_Panel.Panel.Slower();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            m.GraphRender();

            if (this.graphWindow == null)
            {
                this.graphWindow = new GraphWindow(this); //!!!!!!!!!!!
                graphWindow.DataContext = m;
                this.graphWindow.Show();
            }
        }
    }
}
