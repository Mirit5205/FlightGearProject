﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorProject.Models
{
    public class JoyStick : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChange(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                Console.WriteLine(propertyName);
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            }
        }

        public Dictionary<string, Tuple<double, double>> rangeDict = new Dictionary<string, Tuple<double, double>>()
        {
            {"aileron",Tuple.Create(0.34,-0.244)},
            {"elevator",Tuple.Create(0.4,-0.4)}
        };

        //Returns difference in percentage based of of mean 
        // Important to not we return as a negative or positive based of if we 
        // are below starting positon (mean) or above and based off of that I know 
        // how much to move in which direction!
        private int calcPercentageAndMovementA(Tuple<double, double> rT, float val)
        {

            //var flt1 = float.Parse(val);

            // return a negative value he is going left
            if (val >= 0)
            {
                var percent = ((val / rT.Item1) * 100); var tmpL = -1 * ((percent / 100) * 25);
                return (int)tmpL;
            }

            //return a positive value he is going right we started with a negative value
            var NegativePercent = (-1 * ((val / rT.Item2) * 100)); var tmpR = 1 * ((NegativePercent / -100) * 25);
            return (int)tmpR;


        }

        // First val is actual value taken from flightgear second value is what we have converted 
        // to percentage for movment to be done relative to mean 
        private List<string> AileronList = new List<string> { "0", "125" };


        public string Aileron
        {
            get { return AileronList[1]; }


            set
            {
                AileronList[0] = value; var change = calcPercentageAndMovementA(this.rangeDict["aileron"], float.Parse(AileronList[0]));

                change = change + 125; AileronList[1] = change.ToString(); OnPropertyChange("Aileron");
            }

        }

        // Their the exact same function but its very confusing to put for both therfore for easier understanding 
        // I decided to rewrite the function twice 
        private int calcPercentageAndMovementE(Tuple<double, double> rT, float val)
        {

            // return a negative value he is going Down
            if (val >= 0)
            {
                var percent = ((val / rT.Item1) * 100); var tmpL = -1 * ((percent / 100) * 25);
                return (int)tmpL;
            }
            //return a positive value he is UP we started with a negative value
            var NegativePercent = (-1 * ((val / rT.Item2) * 100)); var tmpR = 1 * ((NegativePercent / -100) * 25);
            return (int)tmpR;


        }

        private List<string> ElevatorList = new List<string> { "0", "125" };
        public string Elevator
        {
            get { return ElevatorList[1]; }

            set
            {
                ElevatorList[0] = value; var change = calcPercentageAndMovementE(this.rangeDict["aileron"], float.Parse(ElevatorList[0]));
                change = change + 125 - 10;
                ElevatorList[1] = change.ToString();
                if (change > 150) { ElevatorList[1] = "150"; }
                if (change < 100) { ElevatorList[1] = "100"; }
                OnPropertyChange("Elevator");
            }
        }

    }
}
