﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorProject.Models
{
    public class RudderComponent : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                Console.WriteLine(propertyName);
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        private List<float> RudderList = new List<float> { 0, 0 };

        // Leave for now like this rudder does not change at all, if shithead decides to change this 
        // will change with it
        public float Rudder
        {
            get { return RudderList[1]; }

            set
            {
                RudderList[0] = value; RudderList[1] = RudderList[0] * 100;
                OnPropertyChange("Rudder");
            }
        }
    }
}
