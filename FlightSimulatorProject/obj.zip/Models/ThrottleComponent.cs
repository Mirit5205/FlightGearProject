﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorProject.Models
{
    public class ThrottleComponent
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                Console.WriteLine(propertyName);
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }



        private List<float> ThrottleList = new List<float> { 0, 0 };

        public float Throttle
        {
            get { return ThrottleList[1]; }

            set
            {
                ThrottleList[0] = value; ThrottleList[1] = ThrottleList[0] * 100;
                OnPropertyChange("Throttle");
            }
        }
        
    }
}
