﻿using OxyPlot;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorProject.Interfaces
{
    interface IServer : INotifyPropertyChanged
    {
        void Open();

        void Close();
        string[] Read();
        void ReadThread();

        Func<double, double> getCurve(string feature);

        List<DataPoint> getCurvePoints(string feature);


        double getMinGraphBoundery(string feature);
        double getMaxGraphBoundery(string feature);
        bool Stop { get; set; }
        public DataPoint LastFeaturePoint { get; set; }
        public DataPoint LastCorrelatedFeaturePoint { get; set; }
        public DataPoint LastLinearRegressionPoint { get; set; }

        public int DataSize { get; }
        string Feature { get; set; }
        string CorrelatedFeature { get; set; }


    }
}
