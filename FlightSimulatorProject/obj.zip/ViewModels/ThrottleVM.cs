﻿using FlightSimulatorProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorProject.ViewModels
{
    class ThrottleVM
    {
        private ThrottleComponent ThrottleModel;
        public ThrottleVM(ThrottleComponent ThrottleModel_Original)
        {
            ThrottleModel = ThrottleModel_Original;

            ThrottleModel.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            {
                Console.WriteLine(e.PropertyName);
                OnPropertyChange(e.PropertyName + "_VM");
            };

        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                Console.WriteLine(propertyName);
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            }
        }


        public float Throttle_VM
        {
            get { return ThrottleModel.Throttle; }
        }
    }
}
