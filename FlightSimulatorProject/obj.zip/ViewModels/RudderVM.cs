﻿using FlightSimulatorProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSimulatorProject.ViewModels
{
    public class RudderVM
    {

        private RudderComponent RudderModel;
        public RudderVM(RudderComponent RudderModel_Original)
        {
            RudderModel = RudderModel_Original;

            RudderModel.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            {
                Console.WriteLine(e.PropertyName);
                OnPropertyChange(e.PropertyName + "_VM");
            };

        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                Console.WriteLine(propertyName);
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            }
        }




        public float Rudder_VM
        {

            get { return RudderModel.Rudder; }

        }
    }
}
